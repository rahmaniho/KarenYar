import{j as t}from"./vendor-ui-DzZGWwCU.js";import{L as o}from"./vendor-react-DPPxx6lp.js";import{w as r,B as i}from"./index-D9tksz4m.js";import{E as s}from"./EmptyState-C_MUOy63.js";import"./vendor-charts-BbtmzwRQ.js";import"./vendor-data-0ZYyVV8e.js";/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=r("Compass",[["path",{d:"m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z",key:"9ktpf1"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]]);function l(){return t.jsx(s,{icon:a,title:"این صفحه پیدا نشد",description:"آدرسی که وارد کرده‌اید وجود ندارد یا جابه‌جا شده است.",action:t.jsx(i,{asChild:!0,children:t.jsx(o,{to:"/",children:"بازگشت به داشبورد"})})})}export{l as NotFoundPage};
