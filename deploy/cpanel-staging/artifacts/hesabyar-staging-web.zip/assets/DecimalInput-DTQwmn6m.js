import{w as f,I as l,ae as m}from"./index-BmUh7tMd.js";import{j as d}from"./vendor-ui-BVGoBzx5.js";import{r as n}from"./vendor-react-DPPxx6lp.js";/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=f("ReceiptText",[["path",{d:"M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z",key:"q3az6g"}],["path",{d:"M14 8H8",key:"1l3xfs"}],["path",{d:"M16 12H8",key:"1fr5h0"}],["path",{d:"M13 16H8",key:"wsln4y"}]]);function I({value:r,onChange:o,onFocus:u,onBlur:c,...i}){const e=Number.isFinite(r)&&r!==0?String(r):"",[p,s]=n.useState(e),a=n.useRef(!1);return n.useEffect(()=>{a.current||s(e)},[e]),d.jsx(l,{...i,dir:"ltr",inputMode:"decimal",value:p,onFocus:t=>{a.current=!0,t.currentTarget.select(),u?.(t)},onChange:t=>{s(t.target.value),o(m(t.target.value)??0)},onBlur:t=>{a.current=!1,s(e),c?.(t)}})}export{I as D,y as R};
