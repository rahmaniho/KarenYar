import{w as s}from"./index-BmUh7tMd.js";import{h as m,E as f}from"./vendor-pdf-uG7fSOCm.js";import{s as l}from"./file-save-BxZPeWIi.js";/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=s("FileDown",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M12 18v-6",key:"17g6i2"}],["path",{d:"m9 15 3 3 3-3",key:"1npd3o"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const k=s("Printer",[["path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",key:"143wyd"}],["path",{d:"M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6",key:"1itne7"}],["rect",{x:"6",y:"14",width:"12",height:"8",rx:"1",key:"1ue0tg"}]]);async function P(d,p){const n=await m(d,{scale:2,useCORS:!0,backgroundColor:"#ffffff",logging:!1}),g=n.toDataURL("image/jpeg",.92),a=new f({orientation:"portrait",unit:"mm",format:"a4"}),c=a.internal.pageSize.getWidth(),i=a.internal.pageSize.getHeight(),t=8,o=c-t*2,e=n.height*o/n.width;if(e<=i-t*2)a.addImage(g,"JPEG",t,t,o,e);else{let h=e,r=t;for(a.addImage(g,"JPEG",t,r,o,e),h-=i-t*2;h>0;)r-=i-t*2,a.addPage(),a.addImage(g,"JPEG",t,r,o,e),h-=i-t*2}await l(p,a.output("blob"))}export{v as F,k as P,P as e};
