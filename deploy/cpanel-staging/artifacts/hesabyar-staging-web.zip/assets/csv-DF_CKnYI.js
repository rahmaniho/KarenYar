import{s as e}from"./file-save-BxZPeWIi.js";function s(n){const t=String(n);return/[",\n;]/.test(t)?`"${t.replaceAll('"','""')}"`:t}function r(n){return"\uFEFF"+n.map(o=>o.map(s).join(",")).join(`\r
`)}async function c(n,t){const o=new Blob([r(t)],{type:"text/csv;charset=utf-8"});await e(n,o)}export{c as d};
