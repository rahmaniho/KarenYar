import{j as t}from"./vendor-ui-BVGoBzx5.js";import{L as o}from"./vendor-react-DPPxx6lp.js";import{w as r,B as i}from"./index-COlloEHx.js";import{E as m}from"./EmptyState-bHNwFt_5.js";import"./vendor-pdf-uG7fSOCm.js";import"./vendor-charts-BbtmzwRQ.js";import"./vendor-data-0ZYyVV8e.js";/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=r("Compass",[["path",{d:"m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z",key:"9ktpf1"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]]);function u(){return t.jsx(m,{icon:s,title:"این صفحه پیدا نشد",description:"آدرسی که وارد کرده‌اید وجود ندارد یا جابه‌جا شده است.",action:t.jsx(i,{asChild:!0,children:t.jsx(o,{to:"/",children:"بازگشت به داشبورد"})})})}export{u as NotFoundPage};
