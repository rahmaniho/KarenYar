import{saveBlob as o}from"./file-save-B34bIRMw.js";function r(n){let t=String(n);return/^[=+\-@\t\r]/.test(t)&&(t=`'${t}`),/[",\n;]/.test(t)?`"${t.replaceAll('"','""')}"`:t}function s(n){return"\uFEFF"+n.map(e=>e.map(r).join(",")).join(`\r
`)}async function i(n,t){const e=new Blob([s(t)],{type:"text/csv;charset=utf-8"});await o(n,e)}export{i as d};
